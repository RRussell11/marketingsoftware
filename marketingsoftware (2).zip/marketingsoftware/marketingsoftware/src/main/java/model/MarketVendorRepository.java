package model;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@SuppressWarnings("hiding")
public interface MarketVendorRepository<Vendor> extends JpaRepository<Vendor,Integer>  {
	@SuppressWarnings("rawtypes")
	public static final MarketVendorRepository marketVendorRepository = null;

    public static List getAllVendors() {
        return (List) marketVendorRepository.findAll();
    }

    public Vendor getVendorById(Integer id);

    public Vendor saveVendor(Vendor vendor);

    public void deleteVendor(Integer id);
}

