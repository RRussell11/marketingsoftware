package model;
import org.antlr.v4.runtime.misc.NotNull;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Vendor {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Id;
	    @NotNull 
	private String name;
	private String Address;
	private String PhoneNumber;
	private String Market;


/*@Override
	public String toString() {
		return "SoftwareVendor [Id=" + Id + ", name=" + name + ", Address=" + Address + ", PhoneNumber=" + PhoneNumber
				+ "]";
	}*/


public Integer getId() {
	return Id;
}


public void setId(Integer id) {
	Id = id;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getAddress() {
	return Address;
}


public void setAddress(String address) {
	Address = address;
}


public String getPhoneNumber() {
	return PhoneNumber;
}


public void setPhoneNumber(String phoneNumber) {
	PhoneNumber = phoneNumber;
}
public String getMarket() {
    return Market;
}

public void setMarket(String market) {
    this.Market = market;
}



public static Vendor getVendorById(Integer id2) {
	// TODO Auto-generated method stub
	return null;
}


public static void deleteVendor(Integer id2) {
	// TODO Auto-generated method stub
	
}


public static Vendor saveVendor(Vendor vendor) {
	// TODO Auto-generated method stub
	return null;
}
}