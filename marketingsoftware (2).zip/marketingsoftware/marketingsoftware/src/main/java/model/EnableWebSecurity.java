package model;

public @interface EnableWebSecurity {

}
