package com.businessApp.marketingsoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootAp
plication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.JdbcTemplate;
@ComponentScan({ "vendorapiservices" })
@SpringBootApplication
public class MarketingsoftwareApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarketingsoftwareApplication.class, args);
		
	}
	
     // user test
	//@Override
	public void run(String... args) throws Exception {
	    String sql = "INSERT INTO vendors (name, email) VALUES ("
	            + "'Nancy Stevens', 'nam@codejava.net')";
	     
	    int rows = update(sql);
	    if (rows > 0) {
	        System.out.println("A new row has been inserted.");
	}
	}

	private int update(String sql) {
		
		int values = 0;
		return values;
	}
}
