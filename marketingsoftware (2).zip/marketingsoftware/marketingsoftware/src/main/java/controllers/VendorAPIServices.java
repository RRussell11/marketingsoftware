package controllers;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import model.MarketVendorRepository;
import model.Vendor;


@SuppressWarnings("unused")
@RequestMapping("/softwarevendor")
@RestController

//Controller class
public class VendorAPIServices {
	
	public VendorAPIServices(String vendorId, String string2, String string3, String string4) {
		
	}

	
	@GetMapping("{/vendors}")
	
	public VendorAPIServices getSoftwareVendorDetails(String vendorId) {
		return new VendorAPIServices("Id:vendorid:V01", "name:vendor1", "Address:Address One", "PhoneNumber:xxxx");
	}
	 @Autowired
	    private Vendor  vendor;
	 private  MarketVendorRepository marketVendorRepository;

	    public List getAllVendors() {
	        return (List) marketVendorRepository.findAll();
	    }

	   
	    @GetMapping("/{id}")
	    public Vendor getVendorById(@PathVariable Integer id) {
	        return Vendor.getVendorById(id);
	    }


	   public Vendor saveVendor(Vendor vendor) {
	        return (Vendor) marketVendorRepository.save(vendor);
	    }

	    
	    @PostMapping
	    public Vendor createVendor(@RequestBody Vendor vendor) {
	        return Vendor.saveVendor(vendor);
	    }

	    @DeleteMapping("/{id}")
	    public void deleteVendor(@PathVariable Integer id) {
	        Vendor.deleteVendor(id);
	    }

}
	
	
